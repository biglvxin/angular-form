import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HelperService } from 'src/app/core/helper/helper.service';
import { environment } from 'src/environments/environment';
import { WelcomeConstant } from '../constant/welcome.constant';

@Injectable({
  providedIn: 'root'
})
export class WelcomeService {
constructor(private http: HttpClient, private helperService: HelperService) { }

// getRegFingingDetails() {
//   return this.http.get(`${environment.ASSETS_URL}/${WelcomeConstant.REG_FINGING_DETAILS}`)
//   .pipe(
//     catchError((error => {return throwError({errorMessage: 'test error http'})}))
//     )
// }
// getRegFingingDetailsPost(params:any) {
//   return this.http.post(`${environment.ASSETS_URL}/${WelcomeConstant.REG_FINGING_DETAILS}`, params)
//   .pipe(
//     catchError((error => {return throwError({errorMessage: 'test error http'})}))
//     )
// }
// getRegFingingDetailsPut(params:any) {
//   return this.http.put(`${environment.ASSETS_URL}/${WelcomeConstant.REG_FINGING_DETAILS}`, params)
//   .pipe(
//     catchError((error => {return throwError({errorMessage: 'test error http'})}))
//     )
// }
// getRegFingingDetailsDelete(params:any) {
//   return this.http.delete(`${environment.ASSETS_URL}/${WelcomeConstant.REG_FINGING_DETAILS}/${params.id}`,)
//   .pipe(
//     catchError((error => {return throwError({errorMessage: 'test error http'})}))
//     )
// }

geTableDetails() {
   let url = `${environment.ASSETS_URL}/${WelcomeConstant.DATA_DETAIL_TEST}`
  return this.http.get(url)
  .pipe(
    catchError((error => {return throwError({errorMessage: 'test error http'})}))
    )
}

getNodeValueByTime(nodes:Array<any>, startTime:any, endTime:any, tempEquipmentSelectionList: Array<any>) {
  const params = {
      startTime: startTime,
      endTime: endTime,
      nodes: nodes,
      tempEquipmentSelectionList:tempEquipmentSelectionList
  }
  console.log(params);

  //  let url = `${environment.ASSETS_URL}/${WelcomeConstant.NODE_VALUE_BY_TIME}`
   let url = `${environment.ASSETS_URL}/${WelcomeConstant.NODE_VLAUE_BY_TIMETAP}`
   
   return this.http.get(url)
  // return this.http.post(url, params)
  .pipe(
    catchError((error => {return throwError({errorMessage: 'test error http'})}))
    )
}
getTreesList() {
  let url = `${environment.ASSETS_URL}/${WelcomeConstant.TREE_LIST}`
 return this.http.get(url)
 .pipe(
   catchError((error => {return throwError({errorMessage: 'test error http'})}))
   )
}

//设置请求头
setHttpOptions (params:any) {
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      Authorization: 'my-auth-token'
    }), 
  };
  return this.http.get(`${environment.ASSETS_URL}/${WelcomeConstant.REG_FINGING_DETAILS}`, {responseType: 'blob'})
  .pipe(
    catchError((error => {return throwError({errorMessage: 'test error http'})}))
    )
}

}
