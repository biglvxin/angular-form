export interface TableColumnName {
    level1Value:string;
    level2Value:string;
    level3Value:string;
    level4Value:string;
    level5Value:string;
    level6Value:string;
    level1Col?:number;
    level2Col?:number;
    level3Col?:number;
    tr?:number;
    startIndex?:number;
    endIndex?:number;

}