export class WelcomeConstant {
    public static REG_FINGING_DETAILS = 'reg-fing-details.json';
    public static DATA_DETAIL = 'data.json';
    public static DATA_DETAIL_TEST = 'test.json';
    
    public static NODE_VALUE_BY_TIME = 'node-value-by-time.json';
    public static NODE_VLAUE_BY_TIMETAP = 'node-value-by-time-equipment.json';
    public static TREE_LIST = 'trees.json';

}