// import { Component, OnInit } from '@angular/core';
// import { WelcomeService } from './services/welcome.service';
// import * as _ from 'lodash';

// import { NzFormatEmitEvent } from 'ng-zorro-antd/tree';
// import * as echarts from 'echarts';
// import { HttpClient } from '@angular/common/http';
// import { cloneDeep } from 'lodash';
// interface TreeNodes {
//   title: string;
//   key: string;
//   expanded?: boolean;
//   children?: Array<TreeNodes>;
//   isLeaf?:boolean;
// }
// export interface TableColumn {
//   level1: string;
//   level2: string;
//   level3: string; 
//   level4: string; 
//   level5: string; 
//   level6: string;
//   level7: string;
//   level8: string;
//   rowspan0?:number;
//   rowspan1?:number;
//   rowspan2?:number;
//   rowspan3?:number;
//   rowspan4?:number;
//   isWarning?: any;
// }
// @Component({
//   selector: 'app-welcome',
//   templateUrl: './welcome.component.html',
//   styleUrls: ['./welcome.component.less']
// })
// export class WelcomeComponent implements OnInit{

//   public myTreeChart: any;
//   public treeCharts: any[] = [];
//   public chartNames: Array<string> = [];
//   public nodeValueByTime = [];
//   public optionsData:any = {};
//   public nodes:Array<TreeNodes> = [];
//   defaultExpandedKeys:Array<string> = [];
//   defaultCheckedKeys: Array<string> = [];
//   public selectNodes:any = [];
//   public startTime:any = new Date(new Date().getTime() - 60*60*24*6*1000);
//   public endTime:any = new Date(new Date().getTime() - 60*60*24*1000);
//   date = [this.startTime, this.endTime];
//   public keyIndex:number = 0;

//   constructor(
//     private welcomeService: WelcomeService,
//     private http: HttpClient
//     ) { }
//     // optionList = [
//     //   { label: 'Lucy', value: 'lucy', age: 20 },
//     //   { label: 'Jack', value: 'jack', age: 22 }
//     // ];
//     // selectedValue = { label: 'Jack', value: 'jack', age: 22 };
  
//     // changeObject(value: { label: string; value: string; age: number }): void {
//     //   console.log(value);
//     // }
//     // compareFn = (o1: any, o2: any): boolean => (o1 && o2 ? o1.value === o2.value : o1 === o2);
//   ngOnInit() {
//     // 获取树型列表
//     this.getTreeLists();
//     // 获取不同时间段节点的数据    
//     this.getNodeValueByTime();

//     // this.getTableData();

//     //test-charts
//     // let mytestcharts = echarts.init(document.querySelector('.test') as any);
//     // let data1 = [
//     //   {name:'2022/12/18 6:38:08', value:['2022/12/18 6:38:08', 80]},
//     //   {name:'2022/12/18 16:18:18', value:['2022/12/18 16:18:18', 60]},
//     //   {name:'2022/12/18 19:18:18', value:['2022/12/18 19:18:18', 90]},

//     //   {name:'2022/12/19 4:38:08', value:['2022/12/19 4:38:08', 70]},
//     //   {name:'2022/12/19 14:18:18', value:['2022/12/19 14:18:18', 50]},
//     //   // {name:'2022/12/19 17:18:18', value:['2022/12/19 17:18:18', 80]}
//     // ];
//     // let data2 = [
//     //   {name:'2022/12/18 7:38:08', value:['2022/12/18 7:38:08', 90]},
//     //   {name:'2022/12/18 18:18:18', value:['2022/12/18 18:18:18', 70]},
//     //   {name:'2022/12/18 20:18:18', value:['2022/12/18 20:18:18', 100]},

//     //   {name:'2022/12/19 5:38:08', value:['2022/12/19 5:38:08', 60]},
//     //   {name:'2022/12/19 15:18:18', value:['2022/12/19 15:18:18', 40]},
//     //   {name:'2022/12/19 18:18:18', value:['2022/12/19 18:18:18', 70]}
//     // ];
    
//     // let anchor = [
//     //   {name:'2022/12/18 00:00:00', value:['2022/12/18 00:00:00', 0]},
//     //   {name:'2022/12/19 00:00:00', value:['2022/12/19 00:00:00', 0]},
//     // ];
//     // let option = {
//     //   tooltip: {
//     //       trigger: 'axis',
//     //       formatter: function (params:any) {
//     //         params = params[0];
//     //         console.log(params);
//     //         return `日期:${params.value[0]}: 值:${params.value[1]}`;
//     //       },
//     //       axisPointer: {
//     //           animation: false
//     //       }
//     //   },
//     //   legend: {
//     //     right: '10%',
//     //     top: '3%',
//     //     textStyle: {
//     //       fontSize: 16
//     //     },
//     //     data: ['机台1', '机台2']
//     //   },
//     //   xAxis: {
//     //     type: 'category',
//     //     name: '日期',
//     //     axisLine: {
//     //       show: true,
//     //       symbol: ['none', 'arrow']
//     //     },
//     //     data: ['2022-01-01', '2022-01-02', '2022-01-03', '2022-01-04', '2022-01-05']         
//     //   },
//     //   yAxis: {
//     //     type: 'value',
//     //     name: '值',
//     //     show: true,
//     //     boundaryGap: [0, '100%'],
//     //     splitLine: {
//     //         show: false
//     //     },
//     //     axisLine: {
//     //       show: true,
//     //       symbol: ['none', 'arrow']
//     //     }
//     //   },
//     //   series: [
//     //     {
//     //       name: '机台1',
//     //       symbolSize: 20,
//     //       data: [
//     //         ["2022-01-01", 8.04],
//     //         ["2022-01-01", 5.95],
//     //         ["2022-01-02", 3.58],
//     //         ["2022-01-03", 10.81],
//     //         ["2022-01-04", 8.33],
//     //         ["2022-01-05", 5.66],
//     //         ["2022-01-02", 1.95],
//     //       ],
//     //       type: 'scatter'
//     //     },
//     //     {
//     //       name: '机台2',
//     //       symbolSize: 20,
//     //       data: [
//     //         ["2022-01-01", 11.04],
//     //         ["2022-01-03", 7.95],
//     //         ["2022-01-02", 5.58],
//     //         ["2022-01-03", 3.81],
//     //         ["2022-01-04", 9.33],
//     //         ["2022-01-05", 7.66],
//     //         ["2022-01-05", 4.95],
//     //       ],
//     //       type: 'scatter'
//     //     }
//     //   ]
//     // };
  
//     // let option = {
//     //     title: {
//     //         text: '动态数据 + 时间坐标轴'
//     //     },
//     //     legend: {
//     //       data: ['机台1', '机台2']
//     //     },
//     //     tooltip: {
//     //         trigger: 'axis',
//     //         formatter: function (params:any) {
//     //             params = params[0];
//     //             let date = new Date(params.name);
//     //             return params.value[0] + ' : ' + params.value[1];
//     //             // return date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear() + ' : ' + params.value[1];
//     //         },
//     //         axisPointer: {
//     //             animation: false
//     //         }
//     //     },
//     //     xAxis: {
//     //         type: 'time',
//     //         splitLine: {
//     //             show: false
//     //         },
//     //         axisLabel: {
//     //           formatter: function (value:any, index:any) {
//     //             //格式化成月/日，只在第一个刻度显示年份
//     //             let date = new Date(value);
//     //             let texts:any = [];
//     //             if (date.getHours() === 0) {
//     //               texts= [date.getFullYear(),(date.getMonth() + 1), date.getDate()];
//     //               return texts.join('-');
//     //             } else {
//     //               texts= [date.getHours(),date.getMinutes()];
//     //               return texts.join(':');
//     //             }
                
//     //           }
//     //         }
            
//     //     },
//     //     yAxis: {
//     //         type: 'value',
//     //         boundaryGap: [0, '100%'],
//     //         splitLine: {
//     //             show: false
//     //         }
//     //     },
//     //     series: [{
//     //         name: '机台1',
//     //         type: 'line',
//     //         showSymbol: true,
//     //         hoverAnimation: false,
//     //         data: data1
//     //     },
//     //     {
//     //       name: '机台2',
//     //       type: 'line',
//     //       showSymbol: false,
//     //       hoverAnimation: false,
//     //       data: data2
//     //   },
//     //     {
//     //         name:'anchor',
//     //         type:'line', 
//     //         showSymbol:false, 
//     //         data:anchor,
//     //         itemStyle:{normal:{opacity:0}},
//     //         lineStyle:{normal:{opacity:0}},
          
//     //     }
//     //   ]
//     // };
//     // console.log(option);
//     // mytestcharts.setOption(option);

//   }
//   tableViewData:any = [];
//   // getTableData() {
//   //   this.http.get('../assets/jsons/test.json').subscribe((data:any) => {
//   //   this.transferTableData(data.table, data.merge);
//   //   });
//   // }
//   // transferTableData(table:any, merge:any) {
//   //   let tableArray:Array<TableColumn> = [];
//   //   table.forEach((item: any) => {
//   //     const keysArr =  Object.keys(item);
//   //     tableArray.push({
//   //       level1: item[keysArr[0]],
//   //       level2: item[keysArr[1]],
//   //       level3: item[keysArr[2]],
//   //       level4: item[keysArr[3]],
//   //       level5: item[keysArr[4]],
//   //       level6: item[keysArr[5]],
//   //       level7: item[keysArr[6]],
//   //       level8: item[keysArr[7]],
//   //       isWarning: true
//   //     });
//   //   });
//   //   merge.forEach((item:any) => {
//   //     const rowspanData = item.endRow - item.startRow +  1;
//   //     if (item.startCol === 4 && item.endCol === 4) {
//   //       tableArray[item.startRow].rowspan4 = rowspanData;
//   //     } else if(item.startCol === 3 && item.endCol === 3) {
//   //       tableArray[item.startRow].rowspan3 = rowspanData;
//   //     } else if(item.startCol === 2 && item.endCol === 2) {
//   //       tableArray[item.startRow].rowspan2 = rowspanData;
//   //     } else if(item.startCol === 1 && item.endCol === 1) {
//   //       tableArray[item.startRow].rowspan1 = rowspanData;
//   //     } else if(item.startCol === 0 && item.endCol === 0) {
//   //       tableArray[item.startRow].rowspan0 = rowspanData;
//   //       this.tableViewData.push(cloneDeep(tableArray).splice(item.startRow, rowspanData));
//   //     }
//   //   });
//   //   console.log( this.tableViewData);
//   // }
//   initValue() {
//     this.defaultExpandedKeys = [];
//     this.defaultCheckedKeys = [];
//     this.chartNames = [];
//     this.treeCharts = [];
//     this.selectNodes = [];
//   }
//   getTreeLists() {
//     this.welcomeService.getTreesList().subscribe((res:any) => {
//       this.nodes = res;
//       this.defaultExpandedKeys = []; // init value
//       this.defaultCheckedKeys = []; // init value
//       this.addTreeKey(this.nodes);
//       this.getDefaultKkeys(this.nodes[0]); 
//       this.defaultCheckedKeys = [this.nodes[0].key]; 
//     });
//   }

//   addTreeKey(nodes:any) {
//     nodes.forEach(((item:any) => {
//       item.key = this.keyIndex++;
//       if (item?.children) {
//         item?.children.forEach((e:any) => {
//           e.key = this.keyIndex++;
//           this.addTreeKey((e?.children || []));
//         })
//       }
//     }))
//   }
//   getDefaultKkeys(currentNode:any) {
//     if (currentNode?.children) {
//       console.log(currentNode);
//       this.defaultExpandedKeys.push(currentNode.key);
//       this.selectNodes.push(currentNode.key);
//       currentNode?.children.forEach((item:any) => {
//         this.getDefaultKkeys(item);
//       })
//     } else {
//       this.selectNodes.push(currentNode.key);
//     }
//   }
//   getNodeValueByTime() {
//     // this.initValue();
//     // this.welcomeService.getNodeValueByTime(this.selectNodes, this.startTime, this.endTime).subscribe((res:any) => {
//     this.welcomeService.getNodeValueByTime(this.nodes, this.startTime, this.endTime).subscribe((res:any) => {
//       this.nodeValueByTime = res;
//       this.getEchartOptions();
//       setTimeout(() => {
//         this.initCharts(this.nodeValueByTime);
//         console.log(this.nodeValueByTime);
//       },0)
//     });
//   }

//   initCharts(data:any) {
//     this.treeCharts = []; // init value
//     data.forEach((item:any, index:number) => {
//       const className = `.diagram${index}`;
//       console.log(className);
//       this.treeCharts.push({index: index,chartNames: this.chartNames[index], chart: echarts.init(document.querySelector(className) as any)})
//     });
//     this.nodeValueByTime.forEach((item:any,index: number) => {
//       this.setEchartOptions(this.treeCharts[index].chart, this.optionsData.seriesData[index], this.optionsData.legendData[index], this.optionsData.xAxisData[index]);
//     });
//   }
//   getEchartOptions() {
//     let options:any = {
//       seriesData: [],
//       legendData:[],
//       xAxisData: []
//     }
//     this.chartNames = [];  // init value
//     this.nodeValueByTime.forEach((item:any) => {
//       this.chartNames.push(item.nodeName);
//       options.legendData.push(item.nodeName);
//       let [time, value]:Array<Array<any>> = [[], []];
//       item.nodeValues.forEach((e:any) => {
//         time.push(e.time);
//         value.push(e.value);
//       });
//       options.seriesData.push({name: item.nodeName, type: 'line', data: value});
//       options.xAxisData.push(time);
//     });
//     this.optionsData = options;
//     console.log(this.optionsData);
//   }
//   setEchartOptions(myTreeChart:any, seriesData: Array<{ name: string; type: string; data: Array<number> }>, legendData:Array<string>,xAxisData: Array<string> ){
//     myTreeChart.showLoading();
//     let setOptionData = {
//       key: {
//         text: 'Stacked Line'
//       },
//       tooltip: {
//         trigger: 'axis'
//       },
//       legend: {
//         data: [legendData]
//       },
//       grid: {
//         left: '3%',
//         right: '4%',
//         bottom: '3%',
//         containLabel: true
//       },
//       xAxis: {
//         type: 'category',
//         name: '日期',
//         nameLocation: 'end',
//         axisTick: { alignWithLabel: true },
//         axisLine: { symbol: ['none', 'arrow'], symbolOffset: 10, symbolSize: [6, 15], onZero: true },
//         data: xAxisData
//       },
//       yAxis: {
//         type: 'value',
//         grid: { top: '200' },
//         axisLine: { symbol: ['none', 'arrow'], show: true, symbolOffset: 10, symbolSize: [6, 15], onZero: true },
//       },
//       series: seriesData
//     }
//     console.log(setOptionData);
//     myTreeChart.setOption(setOptionData);
//     myTreeChart.hideLoading();
//   }
  
//   nzEvent(event: NzFormatEmitEvent): void {
//     this.selectNodes = [];    // init value
//     console.log(this.nodes);
//     // this.getSelectTreeNode(this.nodes);
//     this.getNodeValueByTime();
   
//   }
//   onChange(result: Date[]): void {
//     [this.startTime, this.endTime]=[...this.date];
//     this.getNodeValueByTime();
//   }
 
//   // getSelectTreeNode(data:any) {
//   //   data.forEach((item: any) => {
//   //     if(item?.children) {
//   //       (item.children || []).map((node:any) => {
//   //           if(node?.checked) {
//   //             this.selectNodes.push(node.key);
//   //           }
//   //           if(!node?.isLeaf){
//   //             this.getSelectTreeNode(node.children);
//   //           }
//   //       })
//   //     } else {
//   //       if(item?.checked) {
//   //         this.selectNodes.push(item.key);
//   //       }
//   //     }
//   //   })
//   // }

  

// }


