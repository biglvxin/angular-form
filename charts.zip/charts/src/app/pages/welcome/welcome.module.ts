import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { LoadingService } from 'src/app/core/loading/loading.service';
import { SharedModule } from 'src/app/shared/shared.module';

import { WelcomeRoutingModule } from './welcome-routing.module';

import { WelcomeComponent } from './welcome.component';


@NgModule({
  imports: [
    WelcomeRoutingModule,
    NzLayoutModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    CommonModule
  ],
  declarations: [WelcomeComponent],
  exports: [WelcomeComponent],
  providers: [LoadingService]
})
export class WelcomeModule { }
