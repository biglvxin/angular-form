import { Component, OnInit } from '@angular/core';
import { WelcomeService } from './services/welcome.service';
import * as _ from 'lodash';
import { NzFormatEmitEvent } from 'ng-zorro-antd/tree';
import * as echarts from 'echarts';
import { HttpClient } from '@angular/common/http';
import { cloneDeep } from 'lodash';
import { saveAs } from 'file-saver';



interface TreeNodes {
  title: string;
  key: string;
  expanded?: boolean;
  children?: Array<TreeNodes>;
  isLeaf?:boolean;
}
export interface TableColumn {
  level1: string;
  level2: string;
  level3: string; 
  level4: string; 
  level5: string; 
  level6: string;
  level7: string;
  level8: string;
  rowspan0?:number;
  rowspan1?:number;
  rowspan2?:number;
  rowspan3?:number;
  rowspan4?:number;
  isWarning?: any;
}
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.less']
})
export class WelcomeComponent implements OnInit{

  public myTreeChart: any;
  public treeCharts: any[] = [];
  public chartNames: Array<string> = [];
  public nodeValueByTime = [];
  public optionsData:any = {};
  public nodes:Array<TreeNodes> = [];
  defaultExpandedKeys:Array<string> = [];
  defaultCheckedKeys: Array<string> = [];
  public startTime:any = new Date(new Date().getTime() - 60*60*24*6*1000);
  public endTime:any = new Date(new Date().getTime() - 60*60*24*1000);
  date = [this.startTime, this.endTime];
  public keyIndex:number = 0;
  public tempEquipmentSelectionList: Array<any> =  ['机台1', '机台2']
  public colors: Array<string> = ['#d223e7', '#4962FC', '#4962FC', '#18D070', '#3F77FE', '#01C2F9', '#4962FC', '#4B7CF3' , '#dd3ee5', '#12e78c', '#fe8104', '#01C2F9', '#F4CB29', '#FD9E06']

  constructor(
    private welcomeService: WelcomeService,
    private http: HttpClient
    ) { }    
  ngOnInit() {
    // 获取树型列表
    this.getTreeLists();
    //  this.getTableData();
  }
    tableViewData:any = [];
  getTableData() {
    this.http.get('../assets/jsons/test.json').subscribe((data:any) => {
    this.transferTableData(data.table, data.merge);
    });
  }
  transferTableData(table:any, merge:any) {
    let tableArray:Array<TableColumn> = [];
    table.forEach((item: any) => {
      const keysArr =  Object.keys(item);
      tableArray.push({
        level1: item[keysArr[0]],
        level2: item[keysArr[1]],
        level3: item[keysArr[2]],
        level4: item[keysArr[3]],
        level5: item[keysArr[4]],
        level6: item[keysArr[5]],
        level7: item[keysArr[6]],
        level8: item[keysArr[7]],
        isWarning: true
      });
    });
    merge.forEach((item:any) => {
      const rowspanData = item.endRow - item.startRow +  1;
      if (item.startCol === 4 && item.endCol === 4) {
        tableArray[item.startRow].rowspan4 = rowspanData;
      } else if(item.startCol === 3 && item.endCol === 3) {
        tableArray[item.startRow].rowspan3 = rowspanData;
      } else if(item.startCol === 2 && item.endCol === 2) {
        tableArray[item.startRow].rowspan2 = rowspanData;
      } else if(item.startCol === 1 && item.endCol === 1) {
        tableArray[item.startRow].rowspan1 = rowspanData;
      } else if(item.startCol === 0 && item.endCol === 0) {
        tableArray[item.startRow].rowspan0 = rowspanData;
        this.tableViewData.push(cloneDeep(tableArray).splice(item.startRow, rowspanData));
      }
    });
    console.log( this.tableViewData);
  }
  download():void {
    
    // (document.querySelector('#exportTable table') as any).setAttribute('border', 1)

    // // (document.querySelector('#exportTable table') as any).style.borderLeft="collapse";
    // // (document.querySelector('#exportTable table') as any).style.borderTop="1px solid #f00";
    // // (document.querySelector('#exportTable table tr td, #exportTable table tr th') as any).style.borderBottom="1px solid #f00";
    // // (document.querySelector('#exportTable table tr td, #exportTable table tr th') as any).style.borderRight="1px solid #f00";

    // console.log((document.querySelector('#exportTable table') as any).innerHTML+='<style>table{color: "#f00"}</style>')

    // console.log((document.querySelectorAll('#exportTable table') as any)[0])
    // const blob = new Blob([(document.getElementById('exportTable') as any).innerHTML], {
    //   type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=uft-8"
    // })
    // saveAs(blob, 'test.xls');
    // (document.querySelector('#exportTable table') as any).removeAttribute('border')
    
  }
  initValue(): void {
    this.defaultExpandedKeys = [];
    this.defaultCheckedKeys = [];
    this.chartNames = [];
    this.treeCharts = [];
  }
  getTreeLists() {
    this.welcomeService.getTreesList().subscribe((res:any) => {
      this.nodes = res;
      this.defaultExpandedKeys = []; // init value
      this.defaultCheckedKeys = []; // init value
      this.addTreeKey(this.nodes);
      this.getDefaultKkeys(this.nodes[0]); 
      this.defaultCheckedKeys = [this.nodes[0].key]; 
       // 获取不同时间段节点的数据    
      this.getNodeValueByTime();
    });
  }

  addTreeKey(nodes:any) {
    nodes.forEach(((item:any) => {
      item.key = this.keyIndex++;
      if (item?.children) {
        item?.children.forEach((e:any) => {
          e.key = this.keyIndex++;
          this.addTreeKey((e?.children || []));
        })
      }
    }))
  }
  getDefaultKkeys(currentNode:any) {
    if(currentNode) {
      currentNode.checked = true;
    }
    if (currentNode?.children) {
      this.defaultExpandedKeys.push(currentNode.key);
      currentNode?.children.forEach((item:any) => {
        item.checked = true;
        this.getDefaultKkeys(item);
      })
    }
  }

  getNodeValueByTime() {
    // console.log(this.nodes);
    const [startTime, endTime]=[this.startTime.getTime(), this.endTime.getTime()]
    // this.initValue();
    this.welcomeService.getNodeValueByTime(this.nodes, startTime, endTime, this.tempEquipmentSelectionList).subscribe((res:any) => {
      this.nodeValueByTime = res;
      console.log(this.nodeValueByTime)
      this.getEchartOptions();
      setTimeout(() => {
        this.initCharts(this.nodeValueByTime);
        // console.log(this.nodeValueByTime);
      },0)
    });
  }

  initCharts(data:any) {
    this.treeCharts = []; // init value
    data.forEach((item:any, index:number) => {
      const className = `.diagram${index}`;
      console.log(className);
      this.treeCharts.push({index: index,chartNames: this.chartNames[index], chart: echarts.init(document.querySelector(className) as any)})
    });
    this.nodeValueByTime.forEach((item:any,index: number) => {
      this.setEchartOptions(this.treeCharts[index].chart, index);
    });
  }
  getEchartOptions() {
    let options:any = {
      seriesData: [],
      legendData:[],
      xAxisData: [],
      keyTexts: [],
      sDatasss:[]
    }
    this.chartNames = [];  // init value
    this.nodeValueByTime.forEach((item:any, index:number) => {
      let sDatas:any = [];
      let xDatas:any = [];
      let lDatas:any = [];
      let sDatass: any = [];
      this.chartNames.push(item.nodeName);
      options.keyTexts.push(item.nodeName);
      item.nodeValues.forEach((node:any, index: number) => {
        lDatas.push(node.equipment);
        let sDatasTemp:any = [];
        node.value.forEach((v:any) => {
          xDatas.push(this.transferStingDate(v.date)),
          v.points.forEach((p:any) => {
            sDatasTemp.push([this.transferStingDate(p.time), p.value]);
            sDatass.push(p.value)
            sDatas.push({name:node.equipment, itemStyle: {
              color: this.colors[index],
              borderColor: '#f00',
              borderWidth:5
            }, type: 'line', symbolSize: 20, data: [[this.transferStingDate(p.time), p.value]],
              markLine: {
                symbol: 'none',
                lineStyle:{type:'solid',color:'red'},
                data:[
                  {name:'top',yAxis:5},
                  {name:'bottom',yAxis:8}
                ]
              }},
              
            )
            
          });
        })
       
        // sDatas.push({name:node.equipment, type: 'scatter', symbolSize: 20, data: sDatasTemp})
        
      });
      options.seriesData.push(sDatas);
      options.xAxisData.push([...new Set(xDatas)]);
      options.legendData.push(lDatas);
      options.sDatasss.push(sDatass)
      console.log(options.sDatasss)
    });
    this.optionsData = options;
    console.log(this.optionsData);
  }
  setEchartOptions(myTreeChart:any, index:number){
    myTreeChart.showLoading();
    let setOptionData = {
      // title: {
      //   text: 'test test test ',
      //   backgroundColor:'#fff'
       
      // },
      key: {
        text: this.optionsData.keyTexts[index]
      },
      tooltip: {
        trigger: 'axis'
      },
      // toolbox: {
      //   show : true,
      //   feature : {
      //       mark : {show: true},
      //       // restore : {show: true},
      //       saveAsImage : {
      //           show: true,
      //           pixelRatio: 1,
      //           title : '保存为图片',
      //           type : 'png',
      //           lang : ['点击保存']         
      //       }
      //   }
      // },
      legend: {
        data: this.optionsData.legendData[index],
        itemStyle: {
          borderColor: 'none'
        }
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        name: '日期',
        nameLocation: 'end',
        axisTick: { alignWithLabel: true },
        axisLine: { symbol: ['none', 'arrow'], symbolOffset: 10, symbolSize: [6, 15], onZero: true },
        data: this.optionsData.xAxisData[index]
      },
      yAxis: {
        type: 'value',
        grid: { top: '200' },
        axisLine: { symbol: ['none', 'arrow'], show: true, symbolOffset: 10, symbolSize: [6, 15], onZero: true },
      },
      series: this.optionsData.seriesData[index],
      graphic: {
        type: 'text',     // 类型：文本
        left: 'center',
        top: 'middle',
        silent: true,     // 不响应事件
        invisible: this.optionsData.sDatasss[index].every((item:any)=>{return item!==""}),  // 有数据就隐藏
        style: {
          fill: '#9d9d9d',
          fontWeight: 'bold',
          text: '暂无数据',
          fontFamily: 'Microsoft YaHei',
          fontSize: '25px'
        }
      }
    }
    console.log(this.optionsData.sDatasss.every((item: any) => { return item == "" }))
    console.log(setOptionData);
    myTreeChart.setOption(setOptionData);
    myTreeChart.hideLoading();
  }
  downloadImage() {
    const canvasLists = document.querySelectorAll('canvas');
    console.log(canvasLists);
    if (canvasLists && canvasLists.length) {
      const mainCanvas = document.createElement('canvas');
      const mcContext = mainCanvas.getContext('2d');
      if (mcContext) {
        mainCanvas.width = 1500;
        mainCanvas.height = 500 * canvasLists.length;
        mcContext.fillStyle = 'white';
        mcContext.fillRect(0, 0 , mainCanvas.width, mainCanvas.height);
       (canvasLists || []).forEach((item:any, index: number) => {
         let row  = index;
         let column = 0;
         mcContext.drawImage(item, column * 600 + 50, row * 400 + 100);
       })
       let url = mainCanvas.toDataURL('image/png');
       let a = document.createElement('a');
       a.download = 'test图表截图';
       a.href = url;
       a.click();
      }
    }
  }
  
  nzEvent(event: NzFormatEmitEvent): void {
    // console.log(this.nodes);
    this.getNodeValueByTime();
   
  }
  onChange(result: Date[]): void {
    [this.startTime, this.endTime]=[...this.date];
    this.getNodeValueByTime();
  }
  transferStingDate(timestamp:any) {
    let date = new Date(timestamp);
    return `${date.getFullYear()}-${(date.getMonth() + 1 )}-${date.getDate()}`
  }
 
}


