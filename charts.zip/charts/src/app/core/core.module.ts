import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoadingService } from './loading/loading.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  exports: [LoadingService]
})
export class CoreModule { }
