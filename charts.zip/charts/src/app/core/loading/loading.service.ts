import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class LoadingService {

constructor() { }

private isLoadingStatus_$: Subject<boolean> = new Subject<boolean>();
loadingStatus_$ = this.isLoadingStatus_$.asObservable();

setLoadingStatus(status:boolean) {
    this.isLoadingStatus_$.next(status);
}

}
