import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent implements OnInit {
  isCollapsed = false;
  constructor(private route: ActivatedRoute) {}
  currentRouter: string = '';
  ngOnInit() {
    this.route.url.subscribe(url => {
      console.log(url[0].path);
      this.currentRouter = url[0].path;
    });
  }
  // tableDataTest = [
   
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6, row: 4},
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6}, 
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6,row: 3},
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6, row: 3},
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6, row: 2}, 
  //   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  // ];
  // tableFirtRow = [
  //   {

  //     tr1: {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6, row: 4},
  //     otherTrs: [
  //       {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //       {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //       {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6}, 
  //     ]

  // }
  // ]
  // tableDataOtherRow = [
  //   {
     
  //       tr1:   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6,row: 3},
  //       otherTrs: [
  //         {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //         {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //       ]
      
  //   },
  //   {
      
  //       tr1:   {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6,row: 3},
  //       otherTrs: [
  //         {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //         {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //       ]
  //   },
  //   {
   
  //     tr1: {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6, row: 2}, 
  //     otherTrs: [
  //       {leve1: 1,level2: 2, level3:3, level4: 4, level: 5, level6: 6},
  //     ]
  //   }
    
  // ]




  totalTableValue = [
    {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row:3, },
    {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235'},
    {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235'},
    {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row: 3},
    {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235'},
    {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235'},
    {level1:'RA局部',level2:'每周',level3:'EP-C01',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: 2},
    {level1:'RA局部',level2:'每周',level3:'EP-C01',level4:'Rotation',level5:'>=0.098um',level6:'0.032'},
    {level1:'RA局部',level2:'每周',level3:'EP-C02',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: 2},
    {level1:'RA局部',level2:'每周',level3:'EP-C02',level4:'Rotation',level5:'>=0.098um',level6:'0.032'},
  ];
  // tableViewData = [
  //   [
  //     {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row:3},
  //     {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row:null},
  //     {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row: null},
  //     {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row: 3},
  //     {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row: null},
  //     {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row: null},
  //   ],
  //   [
  //     {level1:'RA局部',level2:'每周',level3:'EP-C01',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: 2},
  //     {level1:'RA局部',level2:'每周',level3:'EP-C01',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: null},
  //     {level1:'RA局部',level2:'每周',level3:'EP-C02',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: 2},
  //     {level1:'RA局部',level2:'每周',level3:'EP-C02',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: null},
  //   ]
  // ]
  // tableViewData = [
  //   {
  //     col1: 'RA全局',
  //     col2: '每日',
  //     col3:  [
  //       {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row:3, startIndex: 0, endIndex: 2},
  //       {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row:null, startIndex: null, endIndex: null},
  //       {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row: null, startIndex: null, endIndex: null},
  //       {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row: 3, startIndex: 3, endIndex: 5},
  //       {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row: null,startIndex: null, endIndex: null},
  //       {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row: null,startIndex: null, endIndex: null},
  //     ],
  //     totalRow: 6,
  //   },
  //   {
  //     col1: 'RA局部',
  //     col2: '每周',
  //     col3:   [
  //       {level1:'RA局部',level2:'每周',level3:'EP-C01',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: 2, startIndex: 0, endIndex: 1},
  //       {level1:'RA局部',level2:'每周',level3:'EP-C01',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: null, startIndex: null, endIndex: null},
  //       {level1:'RA局部',level2:'每周',level3:'EP-C02',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: 2, startIndex: 2, endIndex: 3},
  //       {level1:'RA局部',level2:'每周',level3:'EP-C02',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: null, startIndex: null, endIndex: null},
  //     ],
  //     totalRow: 4,
  //   }
  // ]

  // tableFirstRowViews = [
  //   {
  //     tr1: {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row:3},
  //     otherTrs: [
  //       {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235'},
  //       {level1:'RA全局',level2:'每日',level3:'EP-C01',level4:'Rotation',level5:'>=0.128um',level6:'0.235'},
  //     ]
  //   },
  //   {
  //     tr1:  {level1:'RA局部',level2:'每周',level3:'EP-C01',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: 2},
  //     otherTrs: [
  //       {level1:'RA局部',level2:'每周',level3:'EP-C01',level4:'Rotation',level5:'>=0.098um',level6:'0.032'},
  //     ]
  //   }
  // ];


  // tableOtherRowsViews = [
  //   [
  //     {
  //       tr1: {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235', row: 3},
  //       otherTrs: [
  //         {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235'},
  //         {level1:'RA全局',level2:'每日',level3:'EP-C02',level4:'Rotation',level5:'>=0.128um',level6:'0.235'},
  //       ]
  //     }
  //   ],

  //   [
  //     {
  //       tr1:  {level1:'RA局部',level2:'每周',level3:'EP-C02',level4:'Rotation',level5:'>=0.098um',level6:'0.032', row: 2},
  //       otherTrs: [
  //         {level1:'RA局部',level2:'每周',level3:'EP-C02',level4:'Rotation',level5:'>=0.098um',level6:'0.032'},
  //       ]
  //     }
  //   ]

  // ];
}
