import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzAutocompleteModule } from 'ng-zorro-antd/auto-complete';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzMessageModule } from 'ng-zorro-antd/message';
import { NzAlertModule } from 'ng-zorro-antd/alert';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzBackTopModule } from 'ng-zorro-antd/back-top';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzTreeModule } from 'ng-zorro-antd/tree';
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    NzLayoutModule,
    NzMenuModule,
    NzButtonModule,
    NzAutocompleteModule,
    NzInputModule,
    NzFormModule,
    NzTableModule,
    NzSelectModule,
    NzMessageModule,
    NzAlertModule,
    NzSpinModule,
    NzTabsModule,
    NzBackTopModule,
    NzToolTipModule,
    NzDatePickerModule,
    NzTreeModule
  ],
  exports:[
    NzLayoutModule,
    NzMenuModule,
    NzButtonModule,
    NzAutocompleteModule,
    NzInputModule,
    NzFormModule,
    NzTableModule,
    NzSelectModule,
    NzMessageModule,
    NzAlertModule,
    NzSpinModule,
    NzTabsModule,
    NzBackTopModule,
    NzToolTipModule,
    NzDatePickerModule,
    NzTreeModule
  ],
  providers: [],
})
export class SharedModule { }
